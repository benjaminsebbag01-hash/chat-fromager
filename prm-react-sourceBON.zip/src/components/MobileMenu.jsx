import { useEffect } from 'react'

export default function MobileMenu({ isOpen, onClose }) {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = ''
    }
    return () => {
      document.body.style.overflow = ''
    }
  }, [isOpen])

  return (
    <>
      <div
        id="mobile-menu-overlay"
        onClick={onClose}
        style={{
          display: isOpen ? 'block' : 'none',
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          background: 'rgba(0,0,0,.5)',
          zIndex: 9998,
        }}
      />
      <div
        id="mobile-menu-panel"
        style={{
          display: isOpen ? 'block' : 'none',
          position: 'fixed',
          top: 0,
          right: isOpen ? '0' : '-100%',
          width: '80%',
          maxWidth: '360px',
          height: '100%',
          background: '#fff',
          zIndex: 9999,
          overflowY: 'auto',
          transition: 'right .3s ease',
          boxShadow: '-2px 0 8px rgba(0,0,0,.3)',
        }}
      >
        <div
          style={{
            background: '#232F3E',
            padding: '16px 20px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <span style={{ color: '#fff', fontSize: '18px', fontWeight: 700 }}>Compte</span>
          <div
            id="mobile-menu-close"
            onClick={onClose}
            style={{
              cursor: 'pointer',
              color: '#fff',
              fontSize: '24px',
              lineHeight: 1,
              padding: '4px',
            }}
          >
            &#10005;
          </div>
        </div>
        <div style={{ padding: '16px 20px', borderBottom: '1px solid #D5D9D9' }}>
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '12px',
            }}
          >
            <span style={{ fontSize: '16px', fontWeight: 700, color: '#0F1111' }}>Votre Compte</span>
            <a
              href="#"
              style={{
                fontSize: '13px',
                color: '#007185',
                textDecoration: 'none',
                border: '1px solid #007185',
                borderRadius: '12px',
                padding: '2px 10px',
              }}
            >
              Tout Afficher
            </a>
          </div>
          <a
            href="/abonnements/"
            style={{
              display: 'block',
              fontSize: '14px',
              color: '#0F1111',
              textDecoration: 'none',
              padding: '10px 0',
            }}
          >
            Vos abonnements
          </a>
          <a
            href="#"
            style={{
              display: 'block',
              fontSize: '14px',
              color: '#0F1111',
              textDecoration: 'none',
              padding: '10px 0',
              borderTop: '1px solid #EDEDED',
            }}
          >
            Vos moyens de paiement
          </a>
          <a
            href="#"
            style={{
              display: 'block',
              fontSize: '14px',
              color: '#0F1111',
              textDecoration: 'none',
              padding: '10px 0',
              borderTop: '1px solid #EDEDED',
            }}
          >
            Vos adresses
          </a>
        </div>
      </div>
    </>
  )
}
