import { Link } from 'react-router-dom'

export default function Footer() {
  const year = new Date().getFullYear()

  return (
    <div className="navLeftFooter nav-sprite-v1" id="navFooter">
      <button id="navBackToTop" className="navFooterBackToTopText" aria-label="Retour en haut">
        <div className="navFooterBackToTop">Retour en haut</div>
      </button>

      <div className="navFooterVerticalColumn navAccessibility" role="presentation">
        <div className="navFooterVerticalRow navAccessibility">
          <div className="navFooterLinkCol navAccessibility">
            <div className="navFooterColHead" role="heading" aria-level={6}>
              Pour mieux nous connaître
            </div>
            <ul>
              <li className="nav_first"><a href="#" className="nav_a">À propos de Prime</a></li>
              <li><a href="#" className="nav_a">Carrières</a></li>
              <li><a href="#" className="nav_a">Durabilité</a></li>
              <li className="nav_last"><a href="#" className="nav_a" lang="en">Prime Science</a></li>
            </ul>
          </div>
          <div className="navFooterColSpacerInner navAccessibility" />
          <div className="navFooterLinkCol navAccessibility">
            <div className="navFooterColHead" role="heading" aria-level={6}>
              Gagnez de l'argent
            </div>
            <ul>
              <li className="nav_first"><a href="#" className="nav_a">Vendez avec plus de 47.250 € d'avantages</a></li>
              <li><a href="#" className="nav_a">Vendez sur Prime Business</a></li>
              <li><a href="#" className="nav_a">Vendez sur Prime Handmade</a></li>
              <li><a href="#" className="nav_a">Protégez et développez votre marque</a></li>
              <li><a href="#" className="nav_a">Devenez Partenaire</a></li>
              <li className="nav_last"><a href="#" className="nav_a">Expédié par Prime</a></li>
            </ul>
          </div>
          <div className="navFooterColSpacerInner navAccessibility" />
          <div className="navFooterLinkCol navAccessibility">
            <div className="navFooterColHead" role="heading" aria-level={6}>
              Moyens de paiement Prime
            </div>
            <ul>
              <li className="nav_first"><a href="#" className="nav_a">Carte Prime Business Amex</a></li>
              <li><a href="#" className="nav_a">Cartes de paiement</a></li>
              <li><a href="#" className="nav_a">Paiement en plusieurs fois</a></li>
              <li><a href="#" className="nav_a">Convertisseur de devises Prime</a></li>
              <li><a href="#" className="nav_a">Cartes cadeaux</a></li>
              <li className="nav_last"><a href="#" className="nav_a">Recharge en ligne</a></li>
            </ul>
          </div>
          <div className="navFooterColSpacerInner navAccessibility" />
          <div className="navFooterLinkCol navAccessibility">
            <div className="navFooterColHead" role="heading" aria-level={6}>
              Besoin d'aide ?
            </div>
            <ul>
              <li className="nav_first"><a href="#" className="nav_a">Voir ou suivre vos commandes</a></li>
              <li><a href="#" className="nav_a">Tarifs et options de livraison</a></li>
              <li><a href="#" className="nav_a" lang="en">Prime Prime</a></li>
              <li><a href="#" className="nav_a">Retours et remplacements</a></li>
              <li><a href="#" className="nav_a">Garantie légale</a></li>
              <li className="nav_last"><a href="#" className="nav_a">Service Client</a></li>
            </ul>
          </div>
        </div>
      </div>
      <div className="nav-footer-line" />

      <div className="navFooterLine navFooterLinkLine navFooterPadItemLine">
        <span>
          <div className="navFooterLine navFooterLogoLine">
            <Link to="/abonnements/">
              <div className="nav-logo-base nav-sprite" />
            </Link>
          </div>
        </span>
      </div>

      <div className="navFooterLine navFooterLinkLine navFooterPadItemLine navFooterCopyright">
        <ul>
          <li className="nav_first"><a href="#" className="nav_a">Conditions générales de vente</a></li>
          <li><a href="#" className="nav_a">Vos informations personnelles</a></li>
          <li><a href="#" className="nav_a">Cookies</a></li>
          <li className="nav_last"><a href="#" className="nav_a">Annonces basées sur vos centres d'intérêt</a></li>
        </ul>
        <span>&copy; 1996-{year}, Prime.com Inc. ou ses affiliés</span>
      </div>
    </div>
  )
}
