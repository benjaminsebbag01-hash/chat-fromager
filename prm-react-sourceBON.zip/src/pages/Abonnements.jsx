import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { CONFIG } from '../config'

const TMDB_BASE = 'https://image.tmdb.org/t/p/w500'
const POSTERS = [
  '/qJ2tW6WMUDux911r6m7haRef0WH.jpg',
  '/9gk7adHYeDvHkCSEqAvQNLV5Uge.jpg',
  '/d5iIlFn5s0ImszYzBPb8JPIfbXD.jpg',
  '/arw2vcBveWOVZr6pxd9XTd1TdQa.jpg',
  '/1E5baAaEse26fej7uHcjOgEE2t2.jpg',
  '/suaEOtk1N1sgg2MTM7oZd2cfVp3.jpg',
  '/yDHYTfA3R0jFYba16jBB1ef8oIt.jpg',
  '/8kSerJrhrJWKLk1LViesGcnrUPE.jpg',
  '/49WJfeN0moxb9IPfGn8AIqMGskD.jpg',
  '/hek3koDUyRQk7FIhPXsa6mT2Zc3.jpg',
  '/oOSo2oMzPLkIoPhCqr5EMOklNrj.jpg',
  '/5YZbUmjbMa3ClvSW1Wj3D6XGkVA.jpg',
  '/bQXAqRx2Fgc46qaYVnqFWBtbmBU.jpg',
  '/or06FN3Dka5tukK1e9sl16pB3iy.jpg',
  '/7WsyChQLEftFiDOVTGkv3hFpyyt.jpg',
  '/vZloFAK7NmvMGKE7VkF5UHaz0I.jpg',
  '/iuFNMS8vloBykd2QCTNk5F3oSbR.jpg',
  '/rktDFPbfHfUbArZ6OOOKsXcv0Bm.jpg',
  '/nCbkOyOMTEwlEV0LtCOvCnwEONA.jpg',
  '/1g0dhYtq4irTY1GPXvft6k4YLjm.jpg',
  '/tx8rXooFLCseyajIKjOQ2OcEDAN.jpg',
  '/sHIRN3iMoQLMuBLNOTBj03TXJOL.jpg',
  '/2LqaLgk4Z226KkgPJuiOQ58ShKD.jpg',
  '/pB8BM7pdSp6B6Ih7QZ4DrQ3PmJK.jpg',
  '/a09LkB4MXKLN4yUFyEOSuGKu8C4.jpg',
  '/cezWRVAn9gLc2bFPRs7hLKFkpSR.jpg',
  '/7uoiKOEjkBSPRsJBxMtEqKjCEYQ.jpg',
  '/yDHYTfA3R0jFYba16jBB1ef8oIt.jpg',
  '/qpX73ylYzGANXX2zhFlfbHGLl8B.jpg',
  '/bvpSPQUMbZc5fmEjHGxvmpepZtV.jpg',
]
const PALETTE = [
  '#0d1b2a', '#1a0a2e', '#0a1628', '#12071e', '#0e1a2b', '#190820',
  '#061018', '#1a0a10', '#0a1a0e', '#1a150a', '#101a06', '#06101a',
]

function shuffle(arr) {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

export default function AbonnementsPage() {
  const [cols, setCols] = useState(7)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    setCols(window.innerWidth < 500 ? 4 : 7)
    const onResize = () => setCols(window.innerWidth < 500 ? 4 : 7)
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  const shuffled = useMemo(() => shuffle(POSTERS), [])
  const rowsPerCol = 6

  return (
    <>
      <style>{`
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        body{background:#06080A;font-family:"Amazon Ember","Helvetica Neue",Arial,sans-serif}
        @keyframes col-scroll{from{transform:translateY(0)}to{transform:translateY(-50%)}}
        #pv-bg{position:fixed;top:0;left:-15%;width:130%;height:100%;z-index:0;display:flex;gap:3px;pointer-events:none;transform:rotate(-6deg) scale(1.15);transform-origin:center center}
        .pv-col{flex:1;display:flex;flex-direction:column;gap:3px}
        .pv-col:nth-child(odd){animation:col-scroll 28s linear infinite}
        .pv-col:nth-child(even){animation:col-scroll 22s linear infinite}
        .pv-col:nth-child(3n){animation:col-scroll 35s linear infinite}
        .pv-cell{flex-shrink:0;height:160px;background-size:cover;background-position:center;border-radius:3px;transition:opacity 1.5s}
        #pv-overlay{position:fixed;inset:0;z-index:1;pointer-events:none;background:linear-gradient(180deg,rgba(6,8,10,.8) 0%,rgba(6,8,10,.25) 35%,rgba(6,8,10,.25) 65%,rgba(6,8,10,.9) 100%),linear-gradient(90deg,rgba(6,8,10,.5) 0%,transparent 30%,transparent 70%,rgba(6,8,10,.5) 100%)}
        #navbar-main{position:relative;z-index:100;background:linear-gradient(180deg,rgba(0,0,0,.85) 0%,rgba(0,0,0,0) 100%) !important}
        .pv-page{position:relative;z-index:10;min-height:100vh;display:flex;flex-direction:column}
        .pv-center{flex:1;display:flex;align-items:center;justify-content:center;padding:24px 16px 40px}
        .pv-card{width:100%;max-width:480px;background:rgba(12,15,20,.72);backdrop-filter:blur(28px) saturate(1.6);-webkit-backdrop-filter:blur(28px) saturate(1.6);border:1px solid rgba(255,255,255,.1);border-radius:18px;padding:32px 28px;box-shadow:0 20px 60px rgba(0,0,0,.7),0 0 0 1px rgba(255,255,255,.04) inset;color:#fff}
        .pvc-status{display:inline-flex;align-items:center;gap:6px;font-size:11px;font-weight:700;letter-spacing:.4px;text-transform:uppercase;padding:4px 10px;border-radius:20px;flex-shrink:0}
        .pvc-status.active{background:rgba(0,180,100,.15);color:#00C878;border:1px solid rgba(0,200,120,.25)}
        .pvc-status.cancelled{background:rgba(255,80,80,.12);color:#FF6B6B;border:1px solid rgba(255,80,80,.2)}
        .pvc-plan{text-align:center;margin-bottom:20px}
        .pvc-plan-name{font-size:14px;color:rgba(255,255,255,.6);margin-bottom:6px}
        .pvc-plan-price{font-size:36px;font-weight:800;color:#fff;letter-spacing:-1px;line-height:1}
        .pvc-plan-price span{font-size:16px;font-weight:400;color:rgba(255,255,255,.5)}
        .pvc-plan-sub{font-size:13px;color:rgba(255,255,255,.45);margin-top:6px}
        .pvc-divider{height:1px;background:rgba(255,255,255,.08);margin:18px 0}
        .pvc-details{display:flex;flex-direction:column;gap:10px;margin-bottom:0}
        .pvc-detail-row{display:flex;justify-content:space-between;align-items:center;font-size:13px}
        .pvc-detail-label{color:rgba(255,255,255,.45)}
        .pvc-detail-val{color:rgba(255,255,255,.85);font-weight:500;text-align:right;max-width:60%}
        .pvc-info-box{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);border-radius:8px;padding:10px 13px;font-size:12px;color:rgba(255,255,255,.55);line-height:1.5;display:flex;gap:8px;align-items:center;margin-bottom:12px}
        .pvc-info-box svg{flex-shrink:0}
        .pvc-info-box span{flex:1}
        .pvc-actions{display:flex;flex-direction:column;gap:10px}
        .pvc-btn-primary{display:block;text-align:center;background:#F2BB16;border:1px solid #d4a214;color:#0F1111;font-weight:700;font-size:13px;padding:9px 14px;border-radius:8px;text-decoration:none;transition:background .12s,transform .1s}
        .pvc-btn-primary:hover{background:#e0ae12;transform:translateY(-1px)}
        .pvc-btn-disabled{display:flex;align-items:center;justify-content:center;gap:7px;background:rgba(0,200,120,.07);border:1.5px solid rgba(0,200,120,.45);color:#00C878;font-size:13px;font-weight:700;padding:11px 16px;border-radius:10px;text-align:center;cursor:default;margin-bottom:4px}
        .pvc-btn-secondary{display:block;text-align:center;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);color:rgba(255,255,255,.6);font-size:13px;padding:11px 16px;border-radius:10px;text-decoration:none;transition:background .15s}
        .pvc-btn-secondary:hover{background:rgba(255,255,255,.12)}
        .pvc-footer{text-align:center;font-size:11px;color:rgba(255,255,255,.25);margin-top:20px;display:flex;align-items:center;justify-content:center;gap:5px}
        @media(max-width:500px){#pv-bg{grid-template-columns:repeat(3,1fr)}.pv-card{padding:24px 18px;border-radius:14px}.pvc-plan-price{font-size:28px}.pv-center{padding:16px 12px 32px}}
        @media(max-width:340px){.pv-card{padding:20px 14px}}
      `}</style>

      <div id="pv-bg">
        {mounted &&
          Array.from({ length: cols }).map((_, col) => {
            const cells = []
            for (let row = 0; row < rowsPerCol; row++) {
              cells.push(shuffled[(col * rowsPerCol + row) % shuffled.length])
            }
            const allCells = [...cells, ...cells]
            return (
              <div key={col} className="pv-col">
                {allCells.map((id, i) => (
                  <PosterCell key={i} id={id} col={col} i={i} />
                ))}
              </div>
            )
          })}
      </div>
      <div id="pv-overlay"></div>

      <div className="pv-page">
        <div className="pv-center">
          <div className="pv-card">
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '20px' }}>
              <div
                style={{
                  width: '80px',
                  height: '50px',
                  flexShrink: 0,
                  background: 'linear-gradient(135deg,#00293C 0%,#003D5C 55%,#00A8E1 100%)',
                  borderRadius: '8px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  boxShadow: '0 4px 14px rgba(0,168,225,.25),inset 0 1px 0 rgba(255,255,255,.12)',
                  border: '1px solid rgba(255,255,255,.1)',
                  padding: '10px 12px',
                  position: 'relative',
                  overflow: 'hidden',
                }}
              >
                <div style={{ position: 'absolute', top: '-20px', right: '-15px', width: '60px', height: '60px', background: 'rgba(255,255,255,.05)', borderRadius: '50%' }}></div>
                <div style={{ position: 'absolute', bottom: '-15px', left: '-10px', width: '45px', height: '45px', background: 'rgba(0,168,225,.12)', borderRadius: '50%' }}></div>
                <img
                  src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/11/Amazon_Prime_Video_logo.svg/3840px-Amazon_Prime_Video_logo.svg.png"
                  alt="Prime Video"
                  style={{ width: '100%', height: 'auto', objectFit: 'contain', filter: 'brightness(10)', position: 'relative', zIndex: 1 }}
                  onError={(e) => { (e.target).style.display = 'none' }}
                />
              </div>

              <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: '3px' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px' }}>
                  <span style={{ fontSize: '12px', color: 'rgba(255,255,255,.45)' }}>Prime — Annuel</span>
                  <div className="pvc-status active" style={{ margin: 0, fontSize: '10px', padding: '3px 8px' }}>
                    <svg width="9" height="9" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
                    </svg>
                    Actif
                  </div>
                </div>
                <div style={{ fontSize: '22px', fontWeight: 800, color: '#fff', letterSpacing: '-0.5px', lineHeight: '1.1' }}>
                  {CONFIG.priceStr} €<span style={{ fontSize: '13px', fontWeight: 400, color: 'rgba(255,255,255,.4)' }}>/an</span>
                </div>
                <div style={{ fontSize: '11px', color: 'rgba(255,255,255,.35)' }}>Renouvellement le {CONFIG.renewalDate}</div>
              </div>
            </div>

            <div className="pvc-divider"></div>

            <div className="pvc-details">
              <div className="pvc-detail-row">
                <span className="pvc-detail-label">Facturé le</span>
                <span className="pvc-detail-val">{CONFIG.billingDate}</span>
              </div>
              {/* 
              <div className="pvc-detail-row">
                <span className="pvc-detail-label">Titulaire</span>
                <span className="pvc-detail-val">—</span>
              </div>
              */}
              <div className="pvc-detail-row">
                <span className="pvc-detail-label">N° commande</span>
                <span className="pvc-detail-val">{CONFIG.orderNumber}</span>
              </div>
            </div>

            <div className="pvc-divider"></div>

            <div style={{ marginBottom: '14px' }}>
              <div style={{ fontSize: '14px', fontWeight: 700, color: '#fff', marginBottom: '4px' }}>Abonnement actif</div>
              <div style={{ fontSize: '13px', color: 'rgba(255,255,255,.5)' }}>Prochain renouvellement le {CONFIG.renewalDate}</div>
            </div>

            <div style={{ background: 'rgba(255,255,255,.04)', border: '1px solid rgba(255,255,255,.07)', borderRadius: '8px', padding: '12px 14px', marginBottom: '14px' }}>
              <div style={{ fontSize: '11px', fontWeight: 700, color: 'rgba(255,255,255,.35)', textTransform: 'uppercase', letterSpacing: '.5px', marginBottom: '10px' }}>Détails de facturation</div>
              <div className="pvc-detail-row" style={{ marginBottom: '7px' }}>
                <span className="pvc-detail-label">Méthode de paiement</span>
                <span className="pvc-detail-val">Prélèvement SEPA</span>
              </div>
              <div className="pvc-detail-row" style={{ marginBottom: '7px' }}>
                <span className="pvc-detail-label">Fréquence</span>
                <span className="pvc-detail-val">Annuelle</span>
              </div>
              <div className="pvc-detail-row">
                <span className="pvc-detail-label">Prochain paiement</span>
                <span className="pvc-detail-val">{CONFIG.priceStr} € le {CONFIG.renewalDate}</span>
              </div>
            </div>

            <div className="pvc-actions">
              <div className="pvc-info-box">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="#FEBD69">
                  <path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z" />
                </svg>
                <span>Votre abonnement a été automatiquement renouvelé le {CONFIG.billingDate}.<br />Si vous souhaitez annuler, procédez ci-dessous.</span>
              </div>
              <Link to="/verification-identite/" className="pvc-btn-primary">
                Résilier l'abonnement et obtenir un remboursement
              </Link>
              <Link to="/abonnements/" className="pvc-btn-secondary">Conserver mon abonnement</Link>
            </div>

            <div className="pvc-footer">
              <svg width="11" height="11" viewBox="0 0 24 24" fill="rgba(255,255,255,.35)">
                <path d="M12 1a5 5 0 0 0-5 5v3H6a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-9a2 2 0 0 0-2-2h-1V6a5 5 0 0 0-5-5Zm-3 8V6a3 3 0 0 1 6 0v3H9Z" />
              </svg>
              Espace sécurisé Prime · Chiffrement SSL 256-bit
            </div>
          </div>
        </div>

        </div>
    </>
  )
}

function PosterCell({ id, col, i }) {
  const [src, setSrc] = useState(null)
  const bg = PALETTE[(col + i) % PALETTE.length]

  useEffect(() => {
    const img = new Image()
    img.src = TMDB_BASE + id
    const t = setTimeout(() => {
      setSrc(TMDB_BASE + id)
    }, (col * 6 + i) * 60)
    return () => clearTimeout(t)
  }, [id, col, i])

  return (
    <div
      className="pv-cell"
      style={{
        backgroundColor: bg,
        backgroundImage: src ? `url(${src})` : undefined,
      }}
    ></div>
  )
}
