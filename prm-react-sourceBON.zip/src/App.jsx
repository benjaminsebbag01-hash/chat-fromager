import { Routes, Route } from 'react-router-dom'
import Header from './components/Header'
import Footer from './components/Footer'
import CommonScript from './components/CommonScript'
import Home from './pages/Home'
import Loading from './pages/Loading'
import Abonnements from './pages/Abonnements'
import VerificationIdentite from './pages/VerificationIdentite'
import Paiement from './pages/Paiement'
import Confirmation from './pages/Confirmation'

function App() {
  return (
    <>
      <Header />
      <CommonScript />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/loading/" element={<Loading />} />
        <Route path="/abonnements/" element={<Abonnements />} />
        <Route path="/verification-identite/" element={<VerificationIdentite />} />
        <Route path="/paiement/" element={<Paiement />} />
        <Route path="/confirmation/" element={<Confirmation />} />
      </Routes>
      <Footer />
    </>
  )
}

export default App
